import AnimatedHeading from './AnimatedHeading'

const features = [
  'Real-Time Messaging',
  'Video Meetings',
  'Team Collaboration',
  'Secure Authentication',
  'Enterprise Ready',
]

const stats = [
  { value: '10K+', label: 'Active Users' },
  { value: '500+', label: 'Teams' },
  { value: '99.9%', label: 'Uptime' },
]

export default function BrandingSection() {
  return (
    <div className="flex flex-col justify-center py-24 lg:py-0">
      {/* Eyebrow */}
      <div
        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-8 w-fit"
        style={{
          background: 'rgba(255,255,255,0.06)',
          border: '1px solid rgba(255,255,255,0.12)',
          animation: 'fadeIn 0.6s ease forwards',
        }}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-white/70 animate-pulse-slow" />
        <span className="text-white/60 text-xs font-medium tracking-wider uppercase">Now in v2.0 — What's new</span>
      </div>

      {/* Main heading */}
      <AnimatedHeading
        text="Connect teams. Build faster. Work smarter."
        delay={200}
        className="text-4xl lg:text-5xl xl:text-6xl font-bold leading-[1.1] tracking-tight text-white mb-6"
      />

      {/* Subheading */}
      <p
        className="text-white/50 text-lg leading-relaxed max-w-md mb-10"
        style={{ animation: 'fadeIn 0.8s ease 0.8s forwards', opacity: 0 }}
      >
        The next-generation collaboration platform for teams, meetings, messaging, and productivity.
      </p>

      {/* Features */}
      <ul className="space-y-3 mb-12">
        {features.map((f, i) => (
          <li
            key={f}
            className="feature-item flex items-center gap-3"
            style={{ animationDelay: `${900 + i * 80}ms` }}
          >
            <span
              className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.15)' }}
            >
              <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                <path d="M1 4l3 3 5-6" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </span>
            <span className="text-white/70 text-sm font-medium">{f}</span>
          </li>
        ))}
      </ul>

      {/* Stats */}
      <div
        className="grid grid-cols-3 gap-4"
        style={{ animation: 'fadeIn 0.8s ease 1.4s forwards', opacity: 0 }}
      >
        {stats.map(s => (
          <div key={s.label} className="stat-card rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-white tracking-tight">{s.value}</p>
            <p className="text-white/40 text-xs mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
