import { useState } from 'react'

interface SignupCardProps {
  onSwitchToLogin: () => void
}

export default function SignupCard({ onSwitchToLogin }: SignupCardProps) {
  const [form, setForm] = useState({ first: '', last: '', email: '', password: '', confirm: '' })
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setTimeout(() => setLoading(false), 1800)
  }

  const fields: Array<{ key: keyof typeof form; label: string; type: string; placeholder: string; half?: boolean }> = [
    { key: 'first', label: 'First Name', type: 'text', placeholder: 'John', half: true },
    { key: 'last', label: 'Last Name', type: 'text', placeholder: 'Smith', half: true },
    { key: 'email', label: 'Work Email', type: 'email', placeholder: 'you@company.com' },
    { key: 'password', label: 'Password', type: showPass ? 'text' : 'password', placeholder: '••••••••' },
    { key: 'confirm', label: 'Confirm Password', type: showPass ? 'text' : 'password', placeholder: '••••••••' },
  ]

  return (
    <div
      className="liquid-glass-strong glass-card-glow rounded-3xl p-8 w-full max-w-md mx-auto"
      style={{ animation: 'slideUp 0.7s cubic-bezier(0.34,1.56,0.64,1) 0.3s forwards, float 6s ease-in-out 1.5s infinite', opacity: 0 }}
    >
      {/* Header */}
      <div className="flex flex-col items-center mb-7">
        <div
          className="w-12 h-12 rounded-2xl flex items-center justify-center mb-5"
          style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.18)' }}
        >
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <rect x="2" y="2" width="7" height="7" rx="1.5" fill="white" opacity="0.9"/>
            <rect x="11" y="2" width="7" height="7" rx="1.5" fill="white" opacity="0.6"/>
            <rect x="2" y="11" width="7" height="7" rx="1.5" fill="white" opacity="0.6"/>
            <rect x="11" y="11" width="7" height="7" rx="1.5" fill="white" opacity="0.9"/>
          </svg>
        </div>
        <h2 className="text-2xl font-bold text-white tracking-tight">Create account</h2>
        <p className="text-white/45 text-sm mt-1">Start your free enterprise trial</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Name row */}
        <div className="grid grid-cols-2 gap-3">
          {fields.filter(f => f.half).map(field => (
            <div key={field.key}>
              <label className="block text-white/60 text-xs font-medium mb-1.5 tracking-wide uppercase">{field.label}</label>
              <input
                type={field.type}
                value={form[field.key]}
                onChange={set(field.key)}
                placeholder={field.placeholder}
                className="input-glass w-full px-3 py-3 rounded-xl text-white text-sm placeholder:text-white/25 font-medium"
                required
              />
            </div>
          ))}
        </div>

        {/* Other fields */}
        {fields.filter(f => !f.half).map(field => (
          <div key={field.key}>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-white/60 text-xs font-medium tracking-wide uppercase">{field.label}</label>
              {(field.key === 'password') && (
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="text-white/35 text-xs hover:text-white/60 transition-colors"
                >
                  {showPass ? 'Hide' : 'Show'}
                </button>
              )}
            </div>
            <input
              type={field.type}
              value={form[field.key]}
              onChange={set(field.key)}
              placeholder={field.placeholder}
              className="input-glass w-full px-4 py-3 rounded-xl text-white text-sm placeholder:text-white/25 font-medium"
              required
            />
          </div>
        ))}

        {/* Password strength hint */}
        {form.password.length > 0 && (
          <div className="flex gap-1 mt-1">
            {[1,2,3,4].map(i => (
              <div
                key={i}
                className="h-1 flex-1 rounded-full transition-all duration-300"
                style={{
                  background: form.password.length >= i * 3
                    ? i <= 2 ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.85)'
                    : 'rgba(255,255,255,0.1)'
                }}
              />
            ))}
          </div>
        )}

        {/* ToS */}
        <p className="text-white/30 text-xs leading-relaxed">
          By creating an account, you agree to our{' '}
          <a href="#" className="text-white/50 hover:text-white/80 transition-colors">Terms of Service</a>{' '}
          and{' '}
          <a href="#" className="text-white/50 hover:text-white/80 transition-colors">Privacy Policy</a>.
        </p>

        {/* Submit */}
        <button
          type="submit"
          disabled={loading}
          className="btn-primary w-full py-3 rounded-xl text-sm flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3"/>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.37 0 0 5.37 0 12h4z"/>
              </svg>
              Creating account…
            </>
          ) : 'Create Account →'}
        </button>
      </form>

      {/* Switch to login */}
      <p className="text-center text-white/35 text-sm mt-6">
        Already have an account?{' '}
        <button onClick={onSwitchToLogin} className="text-white/70 hover:text-white transition-colors font-medium">
          Sign In
        </button>
      </p>
    </div>
  )
}
