interface NavbarProps {
  onLogin?: () => void
  onGetStarted?: () => void
}

export default function Navbar({ onLogin, onGetStarted }: NavbarProps) {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 liquid-glass-navbar">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Left: Logo */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center"
               style={{ background: 'rgba(255,255,255,0.12)', border: '1px solid rgba(255,255,255,0.2)' }}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M3 3h4v4H3zM9 3h4v4H9zM3 9h4v4H3zM9 9h4v4H9z" fill="white" opacity="0.9"/>
            </svg>
          </div>
          <div>
            <span className="text-white font-bold text-[15px] tracking-tight">VTL CHAT</span>
            <p className="text-white/35 text-[10px] leading-none mt-0.5 tracking-wider uppercase">Enterprise Collaboration</p>
          </div>
        </div>

        {/* Center: Nav Links */}
        <div className="hidden md:flex items-center gap-8">
          {['Features', 'Teams', 'Meetings', 'Security'].map(link => (
            <a key={link} href="#" className="nav-link">{link}</a>
          ))}
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onLogin}
            className="nav-link px-4 py-2 rounded-xl hover:bg-white/5 transition-all"
          >
            Login
          </button>
          <button
            onClick={onGetStarted}
            className="btn-primary px-4 py-2 rounded-xl text-sm"
          >
            Get Started
          </button>
        </div>
      </div>
    </nav>
  )
}
