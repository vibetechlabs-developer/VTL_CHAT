import { useEffect, useState } from 'react'

interface AnimatedHeadingProps {
  text: string
  className?: string
  delay?: number
}

export default function AnimatedHeading({ text, className = '', delay = 0 }: AnimatedHeadingProps) {
  const [started, setStarted] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setStarted(true), delay)
    return () => clearTimeout(t)
  }, [delay])

  const words = text.split(' ')

  return (
    <h1 className={className}>
      {words.map((word, wi) => (
        <span key={wi} className="inline-block mr-[0.25em]">
          {word.split('').map((char, ci) => {
            const idx = words.slice(0, wi).join('').length + ci
            return (
              <span
                key={ci}
                className="char-animate"
                style={{
                  animationDelay: started ? `${idx * 30}ms` : '9999s',
                  animationFillMode: 'forwards',
                }}
              >
                {char}
              </span>
            )
          })}
        </span>
      ))}
    </h1>
  )
}
