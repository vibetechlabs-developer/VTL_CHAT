import Navbar from '../components/Navbar'
import BrandingSection from '../components/BrandingSection'
import LoginCard from '../components/LoginCard'

interface Props {
  onSwitchToSignup: () => void
}

export default function LoginPage({ onSwitchToSignup }: Props) {
  return (
    <div className="relative min-h-screen">
      {/* Video background */}
      <video
        className="video-bg"
        autoPlay
        loop
        muted
        playsInline
        src="https://cdn.pixabay.com/video/2022/10/04/133588-756890699_large.mp4"
      />

      {/* Page layer */}
      <div className="page-layer page-enter">
        <Navbar onLogin={() => {}} onGetStarted={onSwitchToSignup} />

        {/* Main content */}
        <div className="max-w-7xl mx-auto px-6 pt-16 min-h-screen flex items-center">
          <div className="grid lg:grid-cols-2 gap-16 xl:gap-24 items-center w-full py-16">
            {/* Left: Branding */}
            <BrandingSection />
            {/* Right: Auth card */}
            <div className="flex justify-center lg:justify-end">
              <LoginCard onSwitchToSignup={onSwitchToSignup} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
